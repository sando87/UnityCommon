﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class BaseObject : MonoBehaviour
{
    public BodyCollider Body { get { return GetComponentInChildren<BodyCollider>(); } }
    public AnimatorHelper Animator { get { return GetComponentInChildren<AnimatorHelper>(); } }
    public RendererManager Renderer { get { return GetComponentInChildren<RendererManager>(); } }
    public CharacterPhysics CharacterPhy { get { return GetComponentInChildren<CharacterPhysics>(); } }
    public Health Health { get { return GetComponentInChildren<Health>(); } }
    public CharacterInput CharacterInput { get { return GetComponentInChildren<CharacterInput>(); } }
    public MotionManager MotionManager { get { return GetComponentInChildren<MotionManager>(); } }
    public FsmManager FsmManager { get { return GetComponentInChildren<FsmManager>(); } }
    public CharacterSpec SpecCommon { get { return GetComponentInChildren<CharacterSpec>(); } }
    public UnitPlayerBase PlayerBase { get { return GetComponentInChildren<UnitPlayerBase>(); } }
    public InteractReceiverMain InteractReceiver { get { return GetComponentInChildren<InteractReceiverMain>(); } }

    public long ResourceID { get { return GetComponentInChildren<MapEditorObject>().resourceID; } }
    
    // 캐릭터의 기저 참조시스템 바뀔때마다 업데이트 해줘야함.
    public void UpdateAnimator() { }
    public void UpdateRenderer() { }

    public void CallInitiator()
    {
        IInitiator[] initiators = GetComponentsInChildren<IInitiator>();
        foreach(IInitiator initiator in initiators)
            initiator.OnInitialize();
    }
    public void CallAwake()
    {
        IInitiator[] initiators = GetComponentsInChildren<IInitiator>();
        foreach(IInitiator initiator in initiators)
            initiator.OnAwake();
    }

    public int GetLayerMaskAttackable()
    {
        int mask = 0;
        if (gameObject.layer == LayerID.Player)
        {
            mask |= (1 << LayerID.Enemies);
            mask |= (1 << LayerID.Platforms);
            mask |= (1 << LayerID.Projectiles);
            mask |= (1 << LayerID.Hitable);
            mask |= (1 << LayerID.HitablePlayerOnly);
        }
        else if (gameObject.layer == LayerID.Enemies)
        {
            mask |= (1 << LayerID.Player);
            mask |= (1 << LayerID.Platforms);
            mask |= (1 << LayerID.PlatformsThin);
            mask |= (1 << LayerID.Hitable);
        }
        else if (gameObject.layer == LayerID.Props)
        {
            mask |= (1 << LayerID.Player);
            mask |= (1 << LayerID.Enemies);
            mask |= (1 << LayerID.Platforms);
            mask |= (1 << LayerID.Hitable);
        }
        else if (gameObject.layer == LayerID.Platforms)
        {
            mask |= (1 << LayerID.Player);
            mask |= (1 << LayerID.Enemies);
            mask |= (1 << LayerID.Platforms);
            mask |= (1 << LayerID.Hitable);
        }
        
        return mask;
    }

    public bool IsOpposite(int layerID)
    {
        if (gameObject.layer == LayerID.Player)
        {
            return layerID == LayerID.Enemies;
        }
        else if (gameObject.layer == LayerID.Enemies)
        {
            return layerID == LayerID.Player;
        }
        
        return false;
    }

    public int GetLayerMaskOpposite()
    {
        if (gameObject.layer == LayerID.Player)
        {
            return 1 << LayerID.Enemies;
        }
        else if (gameObject.layer == LayerID.Enemies)
        {
            return 1 << LayerID.Player;
        }

        return 0;
    }

    public bool IsMapObject()
    {
        return GetComponentInChildren<MapEditorObject>() != null;
    }
    public bool IsOnLadder()
    {
        Ladderable ladderable = GetComponentInChildren<Ladderable>();
        return ladderable != null && ladderable.IsOnLadder;
    }
    public bool IsOnTelevator()
    {
        Televatable televatable = GetComponentInChildren<Televatable>();
        return televatable != null && televatable.IsOnTelevator;
    }
    public bool IsBurning()
    {
        Burnable burnable = GetComponentInChildren<Burnable>();
        return burnable != null && burnable.IsBurning;
    }
    public bool IsTargetFront(BaseObject target)
    {
        return (transform.right.x * GetTargetDir(target)) > 0;
    }
    public bool IsTargetFront(Vector3 targetPos)
    {
        return (transform.right.x * GetTargetDir(targetPos)) > 0;
    }
    public float GetTargetDir(BaseObject target)
    {
        if(target == null) return 1;
        return target.transform.position.x > transform.position.x ? 1 : -1;
    }
    public float GetTargetDir(Vector3 targetPos)
    {
        return targetPos.x > transform.position.x ? 1 : -1;
    }
    
    public void SetBodyCenterPosition(Vector3 bodyCenterPos)
    {
        transform.position = bodyCenterPos - Body.OffsetFromBaseObjct;
    }
    public void AttachOnTheRightOf(BaseObject target)
    {
        Vector3 sizehalf = Body.Size * 0.5f;
        Vector3 targetSizehalf = target.Body.Size * 0.5f;
        float newCenPosX = target.Body.Center.x + targetSizehalf.x + sizehalf.x;
        Vector3 curCenter = Body.Center;
        curCenter.x = newCenPosX;
        SetBodyCenterPosition(curCenter);
    }
    public void AttachOnTheLeftOf(BaseObject target)
    {
        Vector3 sizehalf = Body.Size * 0.5f;
        Vector3 targetSizehalf = target.Body.Size * 0.5f;
        float newCenPosX = target.Body.Center.x - targetSizehalf.x - sizehalf.x;
        Vector3 curCenter = Body.Center;
        curCenter.x = newCenPosX;
        SetBodyCenterPosition(curCenter);
    }
    public void AttachOnTheTopOf(BaseObject target)
    {
        Vector3 sizehalf = Body.Size * 0.5f;
        Vector3 targetSizehalf = target.Body.Size * 0.5f;
        float newCenPosY = target.Body.Center.y + targetSizehalf.y + sizehalf.y;
        Vector3 curCenter = Body.Center;
        curCenter.y = newCenPosY;
        SetBodyCenterPosition(curCenter);
    }
    public void AttachOnTheBottomOf(BaseObject target)
    {
        Vector3 sizehalf = Body.Size * 0.5f;
        Vector3 targetSizehalf = target.Body.Size * 0.5f;
        float newCenPosY = target.Body.Center.y - targetSizehalf.y - sizehalf.y;
        Vector3 curCenter = Body.Center;
        curCenter.y = newCenPosY;
        SetBodyCenterPosition(curCenter);
    }
    public float ForwardDir
    {
        get { return transform.right.x > 0 ? 1 : -1; }
    }
    public void DestroyBaseObject()
    {
        // base객체를 삭제하기전 자식으로 있는 풀링 객체는 모두 반환 후 삭제(대부분 vfx같은 효과 객체들 반환)
        GameObject[] childs = GetPoolingChildObjects();
        foreach(GameObject child in childs)
        {
            ObjectPooling.Instance.DestroyReturn(child.gameObject);
        }

        Destroy(gameObject);
    }

    public GameObject[] GetPoolingChildObjects()
    {
        List<GameObject> rets = new List<GameObject>();
        foreach(Transform child in transform)
        {
            if(ObjectPooling.IsPoolingable(child.gameObject))
                rets.Add(child.gameObject);
        }
        return rets.ToArray();
    }
    public void TurnForward()
    {
        float degY = (CharacterInput.HorizontalMove > 0) ? 0 : ((CharacterInput.HorizontalMove < 0) ? 180 : (transform.rotation.eulerAngles.y));
        transform.rotation = Quaternion.Euler(0, degY, 0);
    }
    public void LockExtInteract()
    {
        InteractReceiver.LockCounter++;
        InteractReceiverSub[] subs = GetComponentsInChildren<InteractReceiverSub>();
        foreach(InteractReceiverSub sub in subs)
        {
            sub.LockCounter++;
        }
    }
    public void UnLockExtInteract()
    {
        InteractReceiver.LockCounter--;
        InteractReceiverSub[] subs = GetComponentsInChildren<InteractReceiverSub>();
        foreach(InteractReceiverSub sub in subs)
        {
            sub.LockCounter--;
        }
    }
    
    public bool IsInteractable(InteractType type)
    {
        IInteractable interactable = InteractReceiver.GetComponent<IInteractable>();
        if (interactable != null && interactable.IsInteractable(type))
        {
            return true;
        }
        return false;
    }
    public bool InvokeInteract(InteractParam param)
    {
        IInteractable interactable = InteractReceiver.GetComponent<IInteractable>();
        if (interactable != null && interactable.IsInteractable(param.type))
        {
            interactable.OnInteracted(param);
            return true;
        }
        return false;
    }
}
