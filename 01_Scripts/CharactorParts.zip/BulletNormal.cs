using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;

public class BulletNormal : SkillBase
{
    [SerializeField] int BulletDamage = 10;
    [SerializeField] float Distance = 10; // 투사체 날악가는 거리
    [SerializeField] float Duration = 1; // 투사체 날악가는 시간
    [SerializeField][Range(0, 1)] float RandomRange = 0; // 난사되는 정도
    [SerializeField][PrefabSelector(Consts.VFXPath)] string IntroVFX = ""; // 투사체 생성 이펙트
    [SerializeField][PrefabSelector(Consts.VFXPath)] string OutroVFX = ""; // 투사체 터질때 이펙트
    [SerializeField][PrefabSelector(Consts.VFXPath)] string HitVFX = ""; // 투사체 타격시 이펙트
    [SerializeField][SFXSelector] string FireStartSFX = ""; // 투사체 발사시 사운드
    [SerializeField][SFXSelector] string FireEndSFX = ""; // 투사체 종료시 사운드

    public Vector3 StartColliderPosition { get; set; } = Vector3.zero;

    void Start()
    {
        if(StartColliderPosition.Equals(Vector3.zero))
        {
            StartColliderPosition = transform.position - (transform.right * 0.1f);
        }
            
    }

    public override void Fire(BaseObject owner)
    {
        base.Fire(owner);
        DoSimpleShot();
    }

    void Update()
    {
        IInteractable hitObj = RaycastInteractable(StartColliderPosition, out Vector3 hitPoint);
        if(hitObj != null)
        {
            ObjectPooling.Instance.InstantiateVFX(HitVFX, hitPoint, Quaternion.identity).ReturnAfter(3);
            hitObj.OnInteracted(new InteractParam(InteractType.Hit, Owner, new DamageInfo(BulletDamage, DamageType.Bullet), hitPoint));
            EndProjectaile();
        }

        StartColliderPosition = transform.position;
    }

    // 투사체 발사 및 충돌시 처리까지 모두 이 함수에서 처리(발사 및 피격시 이펙트 처리까지..)
    void DoSimpleShot()
    {
        SoundPlayManager.Instance.PlayInGameSFX(FireStartSFX);
        // Shoot 시작 효과 생성 후 몇초뒤 삭제
        ObjectPooling.Instance.InstantiateVFX(IntroVFX, transform.position, Quaternion.identity).ReturnAfter(3);

        // 전방 방향으로 발사(이동) 후 종료지점에서 투사체 삭제
        Vector3 dest = transform.position + (transform.right * Distance);
        if(RandomRange > 0)
            dest = MyUtils.Random(dest, RandomRange);

        transform.right = (dest - transform.position).normalized;    
        transform.DOMove(dest, Duration).SetEase(Ease.Linear).OnComplete(() =>
        {
            EndProjectaile();
        });
    }

    private void EndProjectaile()
    {
        SoundPlayManager.Instance.PlayInGameSFX(FireEndSFX);
        // 종료 이펙트 연출 후 사라짐
        ObjectPooling.Instance.InstantiateVFX(OutroVFX, transform.position, Quaternion.identity).ReturnAfter(3);
        transform.DOKill();
        Destroy(gameObject);
    }



}
