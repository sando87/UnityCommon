﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// 캐릭터의 Input을 추상화하여 처리함
// 실제 Input을 넣어주는 class는 UserInput, AI_Input, RemoteInput 참고
// 추상화한 이유는 특정 캐릭터는 제어하는 로직이 상황에 따라 다르기 때문
// 유저가 직접 제어하는 메인 캐릭터, 컴퓨터가 제어하는 몬스터, 멀티플레이어가 제어하는 캐릭터 등등...

public enum CharacterInputType
{
    MoveHori, MoveVert, Jump, AttackNormal, AttackSpecial, AttackMelee, Rolling, Detected, Interact, Pause
}

public class CharacterInput : MonoBehaviour, IMapEditorObject
{
    private int mLockCounter = 0;
    private float[] mInputData = new float[MyUtils.CountEnum<CharacterInputType>()];

    public event Action<CharacterInputType> EventTriggerDown;
    public event Action<CharacterInputType> EventTriggerUp;
    
    protected void InvokeEventsTriggerDown(CharacterInputType type)
    {
        if (Lock) return;

        EventTriggerDown?.Invoke(type);
    }
    protected void InvokeEventsTriggerUp(CharacterInputType type)
    {
        if (Lock) return;

        EventTriggerUp?.Invoke(type);
    }
    public virtual float GetInput(CharacterInputType type)
    {
        return Lock ? 0 : mInputData[(int)type];
    }
    public virtual void SetInput(CharacterInputType type, float value)
    {
        if (Lock) return;

        bool isTriggerDown = mInputData[(int)type] == 0 && value > 0;
        bool isTriggerUp = mInputData[(int)type] != 0 && value == 0;
        
        mInputData[(int)type] = value;

        if(isTriggerDown)
            InvokeEventsTriggerDown(type);
        else if(isTriggerUp)
            InvokeEventsTriggerUp(type);
    }

    public bool Lock 
    { 
        get { return mLockCounter > 0 && enabled; } 
        set { if(value) mLockCounter++; else mLockCounter--; mLockCounter.SetMinimum(0); } 
    }

    public BaseObject TargetDetected = null;
    public Vector3 MoveDir = Vector3.zero;

    public float HorizontalMove { get { return GetInput(CharacterInputType.MoveHori); } }
    public float VerticalMove { get { return GetInput(CharacterInputType.MoveVert); } }
    public bool Jump { get { return GetInput(CharacterInputType.Jump) > 0; } }
    public bool AttackNormal { get { return GetInput(CharacterInputType.AttackNormal) > 0; } }
    public bool AttackSpecial { get { return GetInput(CharacterInputType.AttackSpecial) > 0; } }
    public bool AttackMelee { get { return GetInput(CharacterInputType.AttackMelee) > 0; } }
    public bool Rolling { get { return GetInput(CharacterInputType.Rolling) > 0; } }
    public bool Detected { get { return GetInput(CharacterInputType.Detected) > 0; } }

    // 맵 제작 모드에서 실행시 호출됨(맵 수정시에는 각 객체의 input을 모두 막도록 처리) 
    void IMapEditorObject.OnInitMapEditor()
    {
        Lock = true;
    }
}
