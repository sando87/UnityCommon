﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class CharacterPhysics : MonoBehaviour, IMapEditorObject, IInitiator
{
    [Range(0, 1)][SerializeField] float GravityMod = 1.0f;
    [SerializeField] float Mass = 1;
    [SerializeField] int OffPixelFromGround = 1;
    [SerializeField] bool _GravityLock = false;
    [SerializeField] bool _DamageOnDrop = false;

    public bool GravityLock 
    { 
        get { return mGravityLockCounter > 0; } 
        set { if(value) mGravityLockCounter++; else mGravityLockCounter--; mGravityLockCounter.SetMinimum(0); }
    }
    public bool CollisionLock { get; set; } = false;
    public float VelocityX { get { return mVelocity.x; } set { mVelocity.x = value; } }
    public float VelocityY { get { return mVelocity.y; } set { mVelocity.y = value; } }
    public void Stop() { mVelocity = Vector3.zero; }

    public Vector3 Velocity { get { return mVelocity; } }
    public float Gravity { get { return Consts.GlobalGravity * GravityMod * (mInGameStarter == null ? 0 : mInGameStarter.IngameSystemGravity); } }
    public float OffsetFromGround { get { return (float)OffPixelFromGround / Consts.PixelPerUnit; } }
    public event Action<Vector3, Vector3> EventCrushed = null; // 인자로 충돌당시 속도, 충돌지점 법선벡터 전달

    // 현재 외부힘에 의해 작용되고 있는 속도와 남은 시간
    private LinkedList<ExtVelInfo> ExtVelocities = new LinkedList<ExtVelInfo>();

    private BaseObject mBaseObject = null;
    private BodyCollider mBody = null;
    private Vector3 mVelocity = Vector3.zero;
    private Rect mMapArea = new Rect();
    private InGameStarter mInGameStarter = null;
    private int mGravityLockCounter = 0;

    public void AddForce(Vector3 power)
    {
        Vector3 startVel = power / Mass;
        ExtVelocities.AddLast(new ExtVelInfo(startVel));
    }

    void Start()
    {
        mBaseObject = this.GetBaseObject();
        mBody = mBaseObject.Body;
        
        mInGameStarter = InGameStarter.FindInstance();
        mMapArea = mInGameStarter.MapArea;

        if(_GravityLock)
            mGravityLockCounter++;

        StartCoroutine(CheckOutOfCamera());
    }

    void Update()
    {
        UpdateNextPosition();

        ReduceExtVelocities();
    }

    private void UpdateNextPosition()
    {
        // 중력으로 인한 위치 조정
        if (!GravityLock && !mBody.IsGrounded)
            mVelocity += new Vector3(0, Gravity, 0) * Time.deltaTime;

        Vector3 curVel = mVelocity;
        curVel += SumExtVelocity();

        if (curVel.sqrMagnitude == 0)
            return;

        // 속도에 따른 다음 위치 조정
        Vector3 previousVelocity = curVel;
        Vector3 diff = curVel * Time.deltaTime;
        mBaseObject.transform.position += diff;

        // 주변 지형에 부딪혔는지 여부 확인(부딪혔을 경우 해당지형에 붙도록 위치 재조정)
        Vector3 crushedNormal = Vector3.zero;
        if(RepositioinFromPlatform(diff, out crushedNormal))
        {
            // 부딪힌 경우..
            GetDamageOnDrop(previousVelocity);
            EventCrushed?.Invoke(previousVelocity, crushedNormal);
        }
    }
    
    bool RepositioinFromPlatform(Vector3 diff, out Vector3 normal)
    {
        normal = Vector3.zero;
        if (CollisionLock)
            return false;

        bool isPlatform = mBody.gameObject.layer == LayerID.Platforms;
        bool isPrevBodyLockState = mBaseObject.Body.Lock;
        int layerMask = 1 << LayerID.Platforms | 1 << LayerID.InGameSystem | 1 << LayerID.PlatformsThin;
        if(isPlatform)
            mBaseObject.Body.Lock = true;

        if(mBody.Collider.GetOverlappedColliders(layerMask, 0.99f).Length <= 0)
        {
            if(!Physics.BoxCast(mBaseObject.Body.Center - diff, mBaseObject.Body.Extents * 0.99f, diff, Quaternion.identity, diff.magnitude, layerMask))
            {
                if(isPlatform)
                    mBaseObject.Body.Lock = isPrevBodyLockState;

                return false;
            }
        }
        
        // 주변 벽이나 지형에 부딪히면 그에 따른 위치 재조정
        float dist = diff.magnitude;
        Vector3 dir = diff.normalized;
        Vector3 center = mBody.Collider.Center();
        Vector3 newCenter = center;
        Vector3 extents = mBody.Collider.size * 0.5f;
        bool isCrushed = false;
        RaycastHit hit = new RaycastHit();
        bool isThinPlatform = false;
        
        if(diff.y < 0)
        {
            Vector3 dirY = new Vector3(0, -1, 0);
            if(Physics.Raycast(mBody.Collider.ForwardDown(0.95f, 0.95f) - new Vector3(0, diff.y, 0), dirY, out hit, extents.y + Mathf.Abs(diff.y), 1 << LayerID.PlatformsThin)
                || Physics.Raycast(mBody.Collider.Down(0.95f) - new Vector3(0, diff.y, 0), dirY, out hit, extents.y + Mathf.Abs(diff.y), 1 << LayerID.PlatformsThin)
                || Physics.Raycast(mBody.Collider.BackDown(0.95f, 0.95f) - new Vector3(0, diff.y, 0), dirY, out hit, extents.y + Mathf.Abs(diff.y), 1 << LayerID.PlatformsThin))
            {
                newCenter.y = hit.point.y + (hit.normal.y * (extents.y + 0.01f));
                VelocityY = 0;
                isCrushed = true;
                normal = hit.normal;
                isThinPlatform = true;
                mBaseObject.SetBodyCenterPosition(newCenter);
            }
        }

        if(diff.y != 0 && !isThinPlatform)
        {
            Vector3 dirY = new Vector3(0, diff.y > 0 ? 1 : -1, 0);
            if(InGameUtils.PlatformsRayCast(mBody.Collider.Forward(0.95f) - new Vector3(0, diff.y, 0), dirY, out hit, extents.y + Mathf.Abs(diff.y))
                || InGameUtils.PlatformsRayCast(mBody.Collider.Center() - new Vector3(0, diff.y, 0), dirY, out hit, extents.y + Mathf.Abs(diff.y))
                || InGameUtils.PlatformsRayCast(mBody.Collider.Back(0.95f) - new Vector3(0, diff.y, 0), dirY, out hit, extents.y + Mathf.Abs(diff.y)))
            {
                newCenter.y = hit.point.y + (hit.normal.y * (extents.y + 0.01f));
                VelocityY = 0;
                isCrushed = true;
                normal = hit.normal;
                isThinPlatform = hit.collider.gameObject.layer == LayerID.PlatformsThin;
                mBaseObject.SetBodyCenterPosition(newCenter);
            }
        }

        if(diff.x != 0)
        {
            Vector3 dirX = new Vector3(diff.x > 0 ? 1 : -1, 0, 0);
            if(InGameUtils.PlatformsRayCast(mBody.Collider.Up(0.95f) - new Vector3(diff.x, 0 ,0), dirX, out hit, extents.x + Mathf.Abs(diff.x))
                || InGameUtils.PlatformsRayCast(mBody.Collider.Center() - new Vector3(diff.x, 0 ,0), dirX, out hit, extents.x + Mathf.Abs(diff.x))
                || InGameUtils.PlatformsRayCast(mBody.Collider.Down(0.95f) - new Vector3(diff.x, 0 ,0), dirX, out hit, extents.x + Mathf.Abs(diff.x)))
            {
                newCenter.x = hit.point.x + (hit.normal.x * (extents.x + 0.01f));
                VelocityX = 0;
                isCrushed = true;
                normal = hit.normal;
                mBaseObject.SetBodyCenterPosition(newCenter);
            }
        }
        
        if(isPlatform)
            mBaseObject.Body.Lock = isPrevBodyLockState;

        //mBaseObject.SetBodyCenterPosition(newCenter);
        return isCrushed;
    }

    void ReduceExtVelocities()
    {
        if(ExtVelocities.Count <= 0)
            return;

        var node = ExtVelocities.First;
        while(node != null)
        {
            ExtVelInfo extVelInfo = node.Value;
            extVelInfo.extVel -= (Consts.ReduceVelocityPerSec * Time.deltaTime) * extVelInfo.dir;
            if(Vector3.Dot(extVelInfo.extVel, extVelInfo.dir) <= 0)
            {
                var nextNode = node.Next;
                ExtVelocities.Remove(node);
                node = nextNode;
            }
            else
            {
                node = node.Next;
            }
        }
    }
    
    // 캐릭터가 화면 아래로 벗어날 경우 죽이고 위로 벗어날 경우 화면 흔들림 처리
    IEnumerator CheckOutOfCamera()
    {
        UnitPlayerBase player = mBaseObject.PlayerBase;
        float offset = player == null ? 10 : 0; // 화면 아래로 offset이상 벗어날 경우 죽임
        float waitTime = player == null ? UnityEngine.Random.Range(0.8f, 1.2f) : 0.1f; // 화면 밖으로 벗어났는지 체크하는 주기(부하를 줄이기 위한 장치)
        while(true)
        {
            // 화면 아래로 벗어났는지 체크
            if(mBody.Center.y < (mMapArea.yMin - offset))
            {
                if(mBaseObject.Health != null)
                {
                    if(player != null)
                        player.ResetPreviousPlayerInfo();
                        
                    mBaseObject.Health.GetDead(mBaseObject, mBaseObject.Body.Center);
                }
                else
                {
                    Destroy(mBaseObject.gameObject);
                }
            }

            // 화면 위로 벗어났는지 체크
            if(player != null && mBody.Center.y > mMapArea.yMax + 2)
            {
                mInGameStarter.ShakeCamera(0.3f);
                if(VelocityY > 0)
                    VelocityY = 0;
            }

            yield return new WaitForSeconds(waitTime);
        }
    }

    // 특정 속도 이상으로 강하게 떨어지면 충격시 속도에 비례하여 데미지를 입는다.
    void GetDamageOnDrop(Vector3 dropVelocity)
    {
        if(!_DamageOnDrop) return;
        
        float velocityThreshold = -5; // 1칸높에서 떨어지면 보통 -9.5, 2칸은 -14.2, 3칸은 -17.3, 4칸은 -20.5
        if(dropVelocity.y < velocityThreshold)
        {
            if(mBaseObject.Health != null)
            {
                // 속도에 비례한 데미지를 입힌다. (보통 10 ~ 30범위로 10단위씩 절상)
                int damage = (int)Mathf.Max(10, Mathf.Abs(dropVelocity.y));
                damage = (damage / 10) * 10;
                mBaseObject.Health.GetDamaged(damage, mBaseObject, mBaseObject.Body.Collider.Down());
            }
        }
    }

    Vector3 SumExtVelocity()
    {
        Vector3 ret = Vector3.zero;
        foreach(ExtVelInfo extVelInfo in ExtVelocities)
            ret += extVelInfo.extVel;
        return ret;
    }
    
    public Vector3[] SimulateLocalPoints(Vector3 startVelocity, float durtaion, float dt)
    {
        List<Vector3> points = new List<Vector3>();

        float time = 0;
        Vector3 pos = Vector3.zero;
        while(time < durtaion)
        {
            startVelocity += new Vector3(0, Consts.GlobalGravity * GravityMod, 0) * dt;
            pos += startVelocity * dt;
            points.Add(pos);
            time += dt;
        }

        return points.ToArray();
    }

    void IMapEditorObject.OnInitMapEditor()
    {
        enabled = false;
    }

    void IInitiator.OnInitialize()
    {
        enabled = false;
    }
    void IInitiator.OnAwake()
    {
        enabled = true;
    }
}

public class ExtVelInfo
{
    public Vector3 extVel;
    public Vector3 dir;
    public ExtVelInfo(Vector3 vel) { extVel = vel; dir = vel.normalized; }

}