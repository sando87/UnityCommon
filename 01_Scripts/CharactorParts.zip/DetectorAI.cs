﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// 이 클래스는 해당 저 AI 캐릭터가 주변에 플레이어를 감지하기 위한 로직.

public class DetectorAI : MonoBehaviour
{
    [SerializeField] public BoxCollider _FrontGroundArea = null;
    
    protected BaseObject mBaseObject = null;
    protected Coroutine mWayChecker = null;

    void Awake()
    {
        mBaseObject = this.GetBaseObject();
    }

    // 주변에 플레이어를 감지한다.(detect범위 안에 있어야 하고 직선거리상 가려지는 지형이 없어야한다.)
    public virtual BaseObject DetectTarget()
    {
        float range = mBaseObject.SpecCommon.DetectRange;
        Collider[] cols = Physics.OverlapSphere(mBaseObject.Body.Center, range, mBaseObject.GetLayerMaskOpposite());
        if(cols.Length > 0)
        {
            Vector3 dir = cols[0].GetBaseObject().Body.Center - mBaseObject.Body.Center;
            if(Physics.Raycast(mBaseObject.Body.Center, dir, out RaycastHit hit, range, mBaseObject.GetLayerMaskAttackable()))
            {
                if(hit.collider.GetBaseObject().gameObject.layer == LayerID.Player)
                {
                    // 전방방향으로 감지거리 안에 있거나
                    if(Vector3.Dot(mBaseObject.transform.right, dir) > 0)
                    {
                        return hit.collider.GetBaseObject();
                    }
                    
                    // 모든방향으로 가까운거리에 있으면
                    if(hit.distance < Consts.AICloseDetectDist)
                    {
                        return hit.collider.GetBaseObject();
                    }
                }
            }
        }
        return null;
    }
    
    // 주변에 공격가능한 플레이어를 감지한다.(보통 캐릭마다 공격 형태가 다르므로 각각 override해서 구현 필요)
    // 기본적으로 적이 공격범위 안에 들어와야하고 둘 사이에 방해되는 블럭이 없으면 공격 가능
    public virtual BaseObject DetectAttackableTarget()
    {
        float range = mBaseObject.SpecCommon.AttackRange;
        Collider[] cols = Physics.OverlapSphere(mBaseObject.Body.Center, range, mBaseObject.GetLayerMaskOpposite());
        if(cols.Length > 0)
        {
            Vector3 dir = cols[0].GetBaseObject().Body.Center - mBaseObject.Body.Center;
            if(Physics.Raycast(mBaseObject.Body.Center, dir, out RaycastHit hit, range, mBaseObject.GetLayerMaskAttackable()))
            {
                if(hit.collider.GetBaseObject().gameObject.layer == LayerID.Player)
                {
                    if(Vector3.Dot(mBaseObject.transform.right, dir) > 0)
                    {
                        return hit.collider.GetBaseObject();
                    }
                }
            }
        }
        return null;
    }

    public void AddEventNoWay(Action eventNoWay)
    {
        ResetEventNoWay();

        mWayChecker = StartCoroutine(CoIsNoWayInvoker(eventNoWay));
    }
    public void ResetEventNoWay()
    {
        if(mWayChecker != null)
            StopCoroutine(mWayChecker);
    }
    IEnumerator CoIsNoWayInvoker(Action eventNoWay)
    {
        float wayCheckerDistance = UnityEngine.Random.Range(0, Consts.AIFrontWayCheckDistance);
        while(!IsNoWay(wayCheckerDistance))
            yield return null;
        eventNoWay?.Invoke();
        mWayChecker = null;
    }
    
    public bool IsNoWay(float wayCheckerDistance = 0)
    {
        Vector3 pos = _FrontGroundArea.Center();
        Vector3 ext = _FrontGroundArea.bounds.extents;
        if(Physics.OverlapBox(pos, ext, Quaternion.identity, 1 << LayerID.Platforms | 1 << LayerID.PlatformsThin).Length == 0)
            return true;

        float dir = mBaseObject.transform.right.x;
        pos += new Vector3(wayCheckerDistance * dir, 0, 0);
        if(Physics.OverlapBox(pos, ext, Quaternion.identity, 1 << LayerID.Platforms | 1 << LayerID.PlatformsThin).Length == 0)
            return true;

        if(wayCheckerDistance > 0)
        {
            if(Physics.Raycast(mBaseObject.Body.Collider.Forward(), mBaseObject.transform.right, out RaycastHit hitDanger, wayCheckerDistance, 1 << LayerID.Hitable))
            {
                if(hitDanger.collider.GetComponent<DangerArea>() != null)
                    return true;
            }

            if(Physics.Raycast(mBaseObject.Body.Collider.Forward(), mBaseObject.transform.right, wayCheckerDistance, 1 << LayerID.Platforms))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        return mBaseObject.Body.IsObstacled;
    }

}
