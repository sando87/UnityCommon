﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// 이 클래스는 해당 저 AI 캐릭터가 주변에 플레이어를 감지하기 위한 로직.(곡사방식으로 탐지 : 장애물 뒤쪽 타겟 감지가능)

public class DetectorAICurve : DetectorAI
{
    public override BaseObject DetectTarget()
    {
        float range = mBaseObject.SpecCommon.DetectRange;
        Collider[] cols = Physics.OverlapSphere(mBaseObject.Body.Center, range, mBaseObject.GetLayerMaskOpposite());
        if(cols.Length > 0)
        {
            BaseObject target = cols[0].GetBaseObject();
            Vector3 dir = target.Body.Center - mBaseObject.Body.Center;
            if(Physics.Raycast(mBaseObject.Body.Center, dir, out RaycastHit hit, range, mBaseObject.GetLayerMaskAttackable()))
            {
                if(hit.collider.GetBaseObject().gameObject.layer == LayerID.Player)
                {
                    // 전방방향으로 감지거리 안에 있거나
                    if(Vector3.Dot(mBaseObject.transform.right, dir) > 0)
                    {
                        return hit.collider.GetBaseObject();
                    }
                    
                    // 모든방향으로 가까운거리에 있으면
                    if(hit.distance < Consts.AICloseDetectDist)
                    {
                        return hit.collider.GetBaseObject();
                    }
                }
            }

            // Curve 방향으로 적을 감지하는 로직
            Vector3 peakPosition = EstimatePeakPosition(target);
            if(IsDetectCurveTarget(target, peakPosition))
            {
                return target;
            }
        }
        return null;
    }

    public override BaseObject DetectAttackableTarget()
    {
        float range = mBaseObject.SpecCommon.AttackRange;
        Collider[] cols = Physics.OverlapSphere(mBaseObject.Body.Center, range, mBaseObject.GetLayerMaskOpposite());
        if(cols.Length > 0)
        {
            BaseObject target = cols[0].GetBaseObject();
            Vector3 dir = target.Body.Center - mBaseObject.Body.Center;
            if(Physics.Raycast(mBaseObject.Body.Center, dir, out RaycastHit hit, range, mBaseObject.GetLayerMaskAttackable()))
            {
                if(hit.collider.GetBaseObject().gameObject.layer == LayerID.Player)
                {
                    if(Vector3.Dot(mBaseObject.transform.right, dir) > 0)
                    {
                        return hit.collider.GetBaseObject();
                    }
                }
            }
            
            // Curve 방향으로 적을 감지하는 로직
            Vector3 peakPosition = EstimatePeakPosition(target);
            if(IsDetectCurveTarget(target, peakPosition))
            {
                return target;
            }
        }
        return null;
    }

    private Vector3 EstimatePeakPosition(BaseObject target)
    {
        Vector3 ret = mBaseObject.transform.position;

        float deltaY = mBaseObject.transform.position.y - target.transform.position.y;
        deltaY = Mathf.Clamp(deltaY, -8, 8);
        float rate = (deltaY + 7) / 16.0f;
        rate = Mathf.Clamp(rate, 0, 1);
        ret.x = (target.transform.position.x * (1 - rate)) + (mBaseObject.transform.position.x * rate);

        float minHeight = Mathf.Max(target.transform.position.y + (Consts.BlockSize * 4), mBaseObject.transform.position.y + (Consts.BlockSize * 2));
        ret.y = minHeight;
        return ret;
    }
    
    private bool IsDetectCurveTarget(BaseObject target, Vector3 peakPosition)
    {
        Vector3 midPoint = peakPosition;
        Vector3 diff = peakPosition - mBaseObject.Body.Center;
        if(Physics.Raycast(mBaseObject.Body.Center, diff, out RaycastHit hit, diff.magnitude, mBaseObject.GetLayerMaskAttackable()))
        {
            midPoint = hit.point + (0.1f * hit.normal);
        }
        
        diff = target.Body.Center - midPoint;
        if(Physics.Raycast(midPoint, diff, out hit, diff.magnitude, mBaseObject.GetLayerMaskAttackable()))
        {
            if(hit.collider.GetBaseObject().gameObject.layer == LayerID.Player)
            {
                return true;
            }
        }
        return false;
    }

}
