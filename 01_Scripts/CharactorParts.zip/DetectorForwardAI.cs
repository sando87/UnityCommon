﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// 이 클래스는 해당 저 AI 캐릭터가 주변에 플레이어를 감지하기 위한 로직.

public class DetectorForwardAI : DetectorAI
{
    // 주변에 플레이어를 감지한다.
    public override BaseObject DetectTarget()
    {
        float range = mBaseObject.SpecCommon.DetectRange;
        Collider[] cols = Physics.OverlapSphere(mBaseObject.Body.Center, range, mBaseObject.GetLayerMaskOpposite());
        if(cols.Length > 0)
        {
            Vector3 dir = mBaseObject.transform.right;
            if(Physics.Raycast(mBaseObject.Body.Center, dir, out RaycastHit hit, range, mBaseObject.GetLayerMaskAttackable()))
            {
                if(hit.collider.GetBaseObject().gameObject.layer == LayerID.Player)
                {
                    if(Vector3.Dot(mBaseObject.transform.right, dir) > 0)
                    {
                        return hit.collider.GetBaseObject();
                    }
                }
            }

            Vector3 diff = cols[0].GetBaseObject().Body.Center - mBaseObject.Body.Center;
            if(diff.magnitude < Consts.AICloseDetectDist)
            {
                if(Physics.Raycast(mBaseObject.Body.Center, diff, out RaycastHit hit2, Consts.AICloseDetectDist, mBaseObject.GetLayerMaskAttackable()))
                {
                    if(hit2.collider.GetBaseObject().gameObject.layer == LayerID.Player)
                    {
                        return hit2.collider.GetBaseObject();
                    }
                }
            }
        }
        return null;
    }

    // 주변에 공격가능한 플레이어를 감지한다.(보통 캐릭마다 공격 형태가 다르므로 각각 override해서 구현 필요)
    // 정면방향의 직선상의 공격 사거리 안에 들어와 있으면 가능(앞뒤 모두 탐색하되 후면 방향은 거리가 짧게 감지)
    public override BaseObject DetectAttackableTarget()
    {
        float range = mBaseObject.SpecCommon.AttackRange;
        Collider[] cols = Physics.OverlapSphere(mBaseObject.Body.Center, range, mBaseObject.GetLayerMaskOpposite());
        if(cols.Length > 0)
        {
            Vector3 dir = mBaseObject.transform.right;
            if(Physics.Raycast(mBaseObject.Body.Center, dir, out RaycastHit hit, range, mBaseObject.GetLayerMaskAttackable()))
            {
                if(hit.collider.gameObject.layer == LayerID.Player)
                {
                    return hit.collider.GetBaseObject();
                }
            }

            if(Physics.Raycast(mBaseObject.Body.Center, -dir, out RaycastHit hitback, Consts.AICloseDetectDist, mBaseObject.GetLayerMaskAttackable()))
            {
                if(hitback.collider.gameObject.layer == LayerID.Player)
                {
                    return hitback.collider.GetBaseObject();
                }
            }
        }
        return null;
    }

}
