﻿using System;
using System.Collections;
using System.Collections.Generic;
using Spine.Unity;
using UnityEngine;

public class FsmBase : MonoBehaviour
{
    public int ID { get { return this.GetInstanceID(); } }

    protected BaseObject mBaseObject = null;
    protected CharacterPhysics mCharacterPhy = null;
    protected FsmManager mFsmManager = null;
    protected AnimatorHelper AnimHelper { get { return mBaseObject.Animator; } }
    protected DetectorAI mDetector = null;

    public event Action EventEnter = null;
    public event Action EventLeave = null;

    public virtual void OnInit()
    {
        mBaseObject = this.GetBaseObject();
        mFsmManager = mBaseObject.FsmManager;
        mCharacterPhy = mBaseObject.CharacterPhy;
        mDetector = mBaseObject.GetComponentInChildren<DetectorAI>();
    }
    public virtual bool OnReady()
    {
        return false;
    }
    public virtual void OnEnter(object param)
    {
        EventEnter?.Invoke();
    }
    public virtual void OnUpdate()
    {
    }
    public virtual void OnLeave()
    {
        EventLeave?.Invoke();
    }

    public bool IsCurrentThis()
    {
        return mFsmManager.IsCurrentFSM(this);
    }
    public bool IsCurrent<T>() where T : FsmBase
    {
        return mFsmManager.IsCurrentFSM<T>();
    }
    public void SwitchFsmState<T>(object param = null) where T : FsmBase
    {
        mFsmManager.SwitchFSM<T>(param);
    }
    public void SwitchFSMToThis()
    {
        mFsmManager.SwitchFSM(this, null);
    }
    public void SwitchFSMToThis(object param)
    {
        mFsmManager.SwitchFSM(this, param);
    }
    public void SwitchFSMToIdle()
    {
        mFsmManager.SwitchFSM<FsmIdle>(null);
    }

    protected void Stop()
    {
        mCharacterPhy.VelocityX = 0;
        AnimHelper.SetAnimParamDerivedType(0);
        AnimHelper.SetTrigger(AnimActionID.Idle);
    }
    protected void MoveTo(BaseObject target, float moveSpeed)
    {
        float dir = (target == null || target.transform.position.x > mBaseObject.transform.position.x) ? 1 : -1;
        mCharacterPhy.VelocityX = dir * moveSpeed;
        mBaseObject.transform.rotation = Quaternion.Euler(0, dir > 0 ? 0 : 180, 0);
        AnimHelper.SetAnimParamDerivedType(0);
        AnimHelper.SetTrigger(AnimActionID.Move);
    }
    protected void MoveForward(float moveSpeed)
    {
        mCharacterPhy.VelocityX = mBaseObject.transform.right.x * moveSpeed;
        AnimHelper.SetAnimParamDerivedType(0);
        AnimHelper.SetTrigger(AnimActionID.Move);
    }
    protected void TransferInteractState(InteractType type, BaseObject originInteractor)
    {
        Vector3 cenPos = mBaseObject.Body.Center;
        Collider[] cols = InGameUtils.RaycastSphereInsideWall(cenPos, 3.0f, 1 << LayerID.Enemies);
        foreach(Collider col in cols)
        {
            col.GetInteracted(new InteractParam(type, originInteractor));
        }
    }

    protected IEnumerator CoPatrolPattern()
    {
        yield return null;
        long tick = 0;
        float waitTime = 1.0f;
        float dir = 1;
        float wayCheckerDistance = 0;
        while(true)
        {
            // 걷다가 서서 주변 경계하는 모션 취한다.
            mCharacterPhy.VelocityX = 0;
            int idx = UnityEngine.Random.Range(0, 3);
            AnimHelper.SetAnimParamDerivedType(idx);
            AnimHelper.SetTrigger(AnimActionID.Alert);
            
            tick = DateTime.Now.Ticks;
            waitTime = UnityEngine.Random.Range(0.3f, 2);
            //걸음을 멈추고 주변 경계 행동을 취하는 시간
            yield return new WaitUntil(() => MyUtils.IsCooltimeOver(tick, waitTime)); 

            // 다시 랜던하게 방향전환 후 이동(길이 없으면 반대반향)
            if(mDetector.IsNoWay(wayCheckerDistance))
                dir *= -1;
            else
                dir = UnityEngine.Random.Range(0, 2) == 0 ? 1 : -1;
                
            // 걷는 모션 시작
            AnimHelper.SetTrigger(AnimActionID.Move);
            mCharacterPhy.VelocityX = dir * mBaseObject.SpecCommon.MoveSpeed;
            mBaseObject.transform.rotation = Quaternion.Euler(0, dir > 0 ? 0 : 180, 0);

            // 앞에 길이 있는지 유무를 체크할때 그 거리개념(캐릭마다 다르게하여 끝자락에 모두 안겹치도록 하기위함)
            wayCheckerDistance = UnityEngine.Random.Range(0, Consts.AIFrontWayCheckDistance);
            
            tick = DateTime.Now.Ticks;
            waitTime = UnityEngine.Random.Range(0.5f, 3);
            // 걷는 시간 설정(주변 길이 없을때까지나 최대 wait시간이 지날때까지 기달)
            yield return new WaitUntil(() => mDetector.IsNoWay(wayCheckerDistance) || MyUtils.IsCooltimeOver(tick, waitTime));
        }
    }
    

    protected bool IsDangerousObject(BaseObject target)
    {
        if(target == null)
            return false;

        SplashDamageOnDead comp = target.GetComponentInChildren<SplashDamageOnDead>();
        if(comp == null || !comp.IsDangerous)
            return false;

        if((mBaseObject.transform.position - target.transform.position).magnitude < (comp.SplashRange * 2))
            return true;
            
        return false;
    }


}