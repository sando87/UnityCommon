using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FsmManager : MonoBehaviour, IMapEditorObject
{
    private Dictionary<int, FsmBase> mFsmes = new Dictionary<int, FsmBase>();
    private FsmBase mStartFSM = null;

    public int CurrentFsmID { get; private set; } = 0;
    public FsmBase CurrentFsm { get { return mFsmes[CurrentFsmID]; } }
    public bool Lock { get; set; } = false;
    public bool IsOutOfControl { get; set; } = false; // 현재 캐릭이 제어 불능 상태(즉, 패닉상태이거나 스턴일 경우)

    void Awake()
    {
        FsmBase[] fsmes = GetComponentsInChildren<FsmBase>();
        foreach (FsmBase fsm in fsmes)
        {
            fsm.OnInit();
            mFsmes[fsm.ID] = fsm;
        }

        if(mStartFSM != null)
        {
            SwitchFSM(mStartFSM, null);
        }
        else
        {
            mStartFSM = FindFsm<FsmIdle>();
            SwitchFSM(mStartFSM, null);
        }
    }

    public void SetStartFSM<T>() where T : FsmBase
    {
        mStartFSM = FindFsm<T>();
    }

    public bool IsCurrentFSM(FsmBase fsm)
    {
        return fsm == CurrentFsm;
    }
    public bool IsCurrentFSM<T>() where T : FsmBase
    {
        return typeof(T).Name == CurrentFsm.GetType().Name;
    }
    public void SwitchFSM<T>(object param) where T : FsmBase
    {
        T fsm = GetComponentInChildren<T>();
        if(fsm != null)
            SwitchFSM(fsm.ID, param);
    }
    public void SwitchFSM(FsmBase fsm, object param)
    {
        SwitchFSM(fsm.ID, param);
    }
    public void SwitchFSM(int fsmID, object param)
    {
        if (!mFsmes.ContainsKey(fsmID)) return;
        if (Lock) return;

        if (CurrentFsmID != 0)
            mFsmes[CurrentFsmID].OnLeave();

        CurrentFsmID = fsmID;
        CurrentFsm.OnEnter(param);
    }
    public T FindFsm<T>() where T : FsmBase
    {
        return GetComponentInChildren<T>();
    }

    void Update() 
    {
        if (Lock) return;

        foreach(var fsm in mFsmes)
        {
            if(fsm.Key == CurrentFsmID) continue;

            if(fsm.Value.OnReady())
            {
                SwitchFSM(fsm.Value, null);
                break;
            }
        }

        if(CurrentFsmID != 0)
            CurrentFsm.OnUpdate();
    }
    
    void IMapEditorObject.OnInitMapEditor()
    {
        Lock = true;
    }

}
