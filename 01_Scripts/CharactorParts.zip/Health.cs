﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;

public class Health : MonoBehaviour, IInitiator
{
    [SerializeField] int _Health = 10;
    [SerializeField] int _Armor = 0;
    [SerializeField] bool _IsImmortal = false;
    [SerializeField] bool _IsBackDamagedOnly = false;

    public event Action<DamageInfo, BaseObject> EventDamaged = null;

    public bool IsDead { get { return CurrentHealth <= 0; } }
    public bool IsLockedDamageable { get { return mLockDamageable > 0; } }
    public int MaxHealth { get { return _Health; } }
    public int CurrentHealth { get; private set; } = 0;
    public float CurrentHealthRate { get { return (float)CurrentHealth / _Health; } }
    public BaseObject LastAttacker { get; private set; } = null;
    public Vector3 LastHitPoint { get; private set; } = Vector3.zero;
    public bool IsBackDamagedOnly { get; set; } = false;

    private BaseObject mBaseObject = null;
    private int mLockDamageable = 0;

    public void LockDamageable(bool isLock) 
    {
        if(isLock) mLockDamageable++;
        else mLockDamageable--;
    }
    public void RefillHealth() { if(!IsDead) CurrentHealth = _Health; }

    void Awake()
    {
        mBaseObject = this.GetBaseObject();
        mLockDamageable = _IsImmortal ? 1 : 0;
        CurrentHealth = _Health;
        IsBackDamagedOnly = _IsBackDamagedOnly;
    }

    void Start()
    {
        // MapEditorObject가 아니면 초반에 Awake해주는 루틴을 안타기때문에 Start()에서 초기화 수행
        if(!mBaseObject.IsMapObject())
        {
            if(mBaseObject.InteractReceiver != null)
                mBaseObject.InteractReceiver.EventInteracted += OnInteracted;
        }
    }

    void IInitiator.OnAwake()
    {
        if(mBaseObject.InteractReceiver != null)
            mBaseObject.InteractReceiver.EventInteracted += OnInteracted;
    }

    void OnInteracted(InteractParam param)
    {
        if(param.type.HasFlag(InteractType.Hit))
        {
            GetDamaged(param.damage, param.interactor, param.hitPoint);
        }
        else if(param.type.HasFlag(InteractType.Dead))
        {
            GetDead(param.interactor, param.hitPoint);
        }
    }

    public void GetDead(BaseObject attacker, Vector3 hitPoint)
    {
        if(IsDead) return;
        
        int damage = CurrentHealth;
        // LastAttacker = attacker;
        CurrentHealth = 0;
        LastHitPoint = hitPoint;
        
        EventDamaged?.Invoke(damage, attacker);
    }
    
    public void GetDamaged(DamageInfo damage, BaseObject attacker, Vector3 hitPoint)
    {
        if(IsDead || IsLockedDamageable) return;

        // 앞쪽방향으로부터 타격을 입었을 경우 데미지 무시
        if(IsBackDamagedOnly && mBaseObject.IsTargetFront(hitPoint)) return;

        // player 캐릭터의 경우 한대 맞으면 무조건 10씩 hp가 닳도록 수정(단 100이상의 데미지는 그대로 받는다.)
        if(mBaseObject.gameObject.layer == LayerID.Player)
        {
            damage.damage = damage <= 100 ? 10 : damage;
        }

        damage -= _Armor;
        if (damage < 0)
            damage = 0;

        // LastAttacker = attacker;
        CurrentHealth -= damage;
        CurrentHealth = Mathf.Max(CurrentHealth, 0);
        LastHitPoint = hitPoint;

        EventDamaged?.Invoke(damage, attacker);
    }

    public void ConsumeStamina(int hp)
    {
        if(IsDead) return;

        CurrentHealth -= hp;
        CurrentHealth = Mathf.Max(CurrentHealth, 0);
        
        if(IsDead)
            EventDamaged?.Invoke(hp, mBaseObject);
    }

    public void LoadHealthInfo(int currentHP)
    {
        CurrentHealth = currentHP;
    }

}
