﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// 사용자가 특정 키에 대해 입력했을때 누른 순간만 감지할지(이경우는 쿨타임 상관없이 빠르게 누르는만큼 빠르게 나감)
// 아니면 계속 누르고 있으면 감지할지 여부 결정(지속적으로 누를경우 설정된 쿨타임 간격으로 입력 처리됨)
public class InputFilter : MonoBehaviour
{
    [SerializeField] CharacterInputType _InputType = CharacterInputType.AttackNormal; //감지할 특정 키
    [SerializeField] InputDetectType _InputDetectType = InputDetectType.All; //감지 타입 설정
    [SerializeField] float _Cooltime = 0.3f; // 입력을 지속적으로 누르고 있을 경우 쿨타임
    [SerializeField] bool _IgnoreCooltimeOnTrigger = true; // Trigger방식 입력시 cooltime 무시하고 누를때마다 무조건 fire되도록 할지 여부

    public Action EventInputDetect { get; set; } = null; // 실제 유효한 입력을 전달한다.
    public CharacterInputType InputType { get { return _InputType; } }

    private CharacterInput mCharInput = null;
    private long mLastDetectTick = 0;

    void Start()
    {
        mCharInput = this.GetBaseObject().CharacterInput;

        if(_InputDetectType.HasFlag(InputDetectType.TriggerDown))
            mCharInput.EventTriggerDown += OnKeyTriggerDown;
            
        if(_InputDetectType.HasFlag(InputDetectType.TriggerUp))
            mCharInput.EventTriggerUp += OnKeyTriggerUp;
    }

    void OnKeyTriggerDown(CharacterInputType type)
    {
        if(type == _InputType)
        {
            if(_IgnoreCooltimeOnTrigger)
            {
                mLastDetectTick = DateTime.Now.Ticks;
                EventInputDetect?.Invoke();
            }
            else
            {
                if(MyUtils.IsCooltimeOver(mLastDetectTick, _Cooltime))
                {
                    mLastDetectTick = DateTime.Now.Ticks;
                    EventInputDetect?.Invoke();
                }
            }
        }
    }
    
    void OnKeyTriggerUp(CharacterInputType type)
    {
        if(type == _InputType)
        {
            if(_IgnoreCooltimeOnTrigger)
            {
                mLastDetectTick = DateTime.Now.Ticks;
                EventInputDetect?.Invoke();
            }
            else
            {
                if(MyUtils.IsCooltimeOver(mLastDetectTick, _Cooltime))
                {
                    mLastDetectTick = DateTime.Now.Ticks;
                    EventInputDetect?.Invoke();
                }
            }
        }
    }

    void Update()
    {
        if(_InputDetectType.HasFlag(InputDetectType.KeepPressing))
        {
            if(MyUtils.IsCooltimeOver(mLastDetectTick, _Cooltime))
            {
                if(mCharInput.GetInput(_InputType) > 0)
                {
                    mLastDetectTick = DateTime.Now.Ticks;
                    EventInputDetect?.Invoke();
                }
            }
        }
    }
}
