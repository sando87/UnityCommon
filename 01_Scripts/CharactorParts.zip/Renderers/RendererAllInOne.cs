using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using Spine.Unity;
using UnityEngine;

public class RendererAllInOne : RendererBase
{
    private Renderer mRenderer = null;
    private MaterialPropertyBlock mBlock = null;
    private int mPropertyToIDColor = 0;
    private int mPropertyToIDAlpha = 0;
    private int mPropertyToIDBrightness = 0;// AddAllIn1Shader 사용해야하고 Contrast & Brightness 항목을 켜줘야한다.
    private int mPropertyToIDGlow = 0;// AddAllIn1Shader 사용해야하고 Glow 항목을 켜줘야한다.

    protected override void Awake()
    {
        base.Awake();

// #if UNITY_EDITOR
//         // 반짝거리는 섬광효과를 주려면 AllIn1Shader에서 Contrast & Brightness 항목을 켜줘야한다.
//         // 이코드를 타면 material 파일 정보를 수정하므로 주의..
//         AllIn1SpriteShader.AllIn1Shader shaderComp = GetComponent<AllIn1SpriteShader.AllIn1Shader>();
//         shaderComp.InvokePrivateMethod("SetKeyword", new object[] { "CONTRAST_ON", true });
// #endif

        mPropertyToIDColor = Shader.PropertyToID("_Color");
        mPropertyToIDAlpha = Shader.PropertyToID("_Alpha");
        mPropertyToIDBrightness = Shader.PropertyToID("_Brightness");
        mPropertyToIDGlow = Shader.PropertyToID("_Glow");

        mBlock = new MaterialPropertyBlock();
        mRenderer = GetComponent<Renderer>();
        mRenderer.GetPropertyBlock(mBlock);
        mBlock.SetColor(mPropertyToIDColor, Color.white);
        mBlock.SetFloat(mPropertyToIDAlpha, 1);
        mBlock.SetFloat(mPropertyToIDBrightness, 0);
        mBlock.SetFloat(mPropertyToIDGlow, 0);
    }

    public override void SetRenderState(bool isShow)
    {
        mRenderer.enabled = isShow;
    }

    public override Color GetColor()
    {
        if(mPropertyToIDColor == 0) return Color.white;

        Color color = mBlock.GetColor(mPropertyToIDColor);
        color.a = 1;
        return color;
    }
    public override void SetColor(Color color)
    {
        if(mPropertyToIDColor == 0) return;

        color.a = 1;
        mBlock.SetColor(mPropertyToIDColor, color);
        mRenderer.SetPropertyBlock(mBlock);
    }
    public override float GetAlpha()
    {
        if(mPropertyToIDAlpha == 0) return 1;

        return mBlock.GetFloat(mPropertyToIDAlpha);
    }
    public override void SetAlpha(float alpha)
    {
        if(mPropertyToIDAlpha == 0) return;

        mBlock.SetFloat(mPropertyToIDAlpha, alpha);
        mRenderer.SetPropertyBlock(mBlock);
    }
    public override float GetBrightness()
    {
        if(mPropertyToIDBrightness == 0) return 1;

        return mBlock.GetFloat(mPropertyToIDBrightness);
    }
    public override void SetBrightness(float brightness)
    {
        if(mPropertyToIDBrightness == 0) return;

        // AddAllIn1Shader 사용해야하고 Contrast & Brightness 항목을 켜줘야한다.
        mBlock.SetFloat(mPropertyToIDBrightness, brightness);
        mRenderer.SetPropertyBlock(mBlock);
    }
    public override float GetGlow()
    {
        if(mPropertyToIDGlow == 0) return 0;

        return mBlock.GetFloat(mPropertyToIDGlow);
    }
    public override void SetGlow(float glow) // 0 ~ 100
    {
        if(mPropertyToIDGlow == 0) return;

        // AddAllIn1Shader 사용해야하고 Glow 항목을 켜줘야한다.
        mBlock.SetFloat(mPropertyToIDGlow, glow);
        mRenderer.SetPropertyBlock(mBlock);
    }


}
