using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using Spine.Unity;
using UnityEngine;

public class RendererBase : MonoBehaviour
{
    protected BaseObject mBaseObject = null;

    protected virtual void Awake()
    {
        mBaseObject = this.GetBaseObject();
    }

    public virtual void SetRenderState(bool isShow) {}
    public virtual Color GetColor() { return Color.white; }
    public virtual void SetColor(Color color) {}
    public virtual float GetAlpha() { return 0; }
    public virtual void SetAlpha(float alpha) {}
    public virtual float GetBrightness() { return 0; }
    public virtual void SetBrightness(float brightness) {}
    public virtual float GetGlow() { return 0; }
    public virtual void SetGlow(float glow) {}
}
