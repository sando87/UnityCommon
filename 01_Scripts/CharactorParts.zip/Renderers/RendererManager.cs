using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using Spine.Unity;
using UnityEngine;

public class RendererManager : MonoBehaviour
{
    [SerializeField] SpineBoneController _WeaponBone = null;

    private BaseObject mBaseObject = null;
    private RendererBase[] mRenderers = null;
    private SkeletonMecanim mSkeletonMecanim = null;
    
    private int mLockCounter = 0;
    public bool Lock 
    { 
        get { return mLockCounter > 0; } 
        set 
        {
            if(value)
                mLockCounter++;
            else
                mLockCounter--;
            mLockCounter.SetMinimum(0);
            foreach(var rd in mRenderers)
                rd.SetRenderState(mLockCounter <= 0);
        }
    }

    void Awake()
    {
        mBaseObject = this.GetBaseObject();

        UpdateRenderers();
    }

    public void UpdateRenderers()
    {
        mSkeletonMecanim = GetComponentInChildren<SkeletonMecanim>();
        mRenderers = GetComponentsInChildren<RendererBase>();
    }


    public void SetColor(Color color)
    {
        foreach(var rd in mRenderers)
        {
            rd.SetColor(color);
        }
    }
    public void SetAlpha(float alpha)
    {
        foreach(var rd in mRenderers)
        {
            rd.SetAlpha(alpha);
        }
    }
    public void SetBrightness(float brightness)
    {
        foreach(var rd in mRenderers)
        {
            rd.SetBrightness(brightness);
        }
    }
    public void SetGlow(float glow) // 0 ~ 100
    {
        foreach(var rd in mRenderers)
        {
            rd.SetGlow(glow);
        }
    }

    // 하얗게 반짝거리는 효과
    public void StartTwinkle()
    {
        SetBrightness(1);
        DOVirtual.DelayedCall(0.1f, () =>
        {
            SetBrightness(0);
        });
    }
    
    // 보였다 안보였다 깜빡거리는 효과
    public void StartBlink(float duration, int blinkCount)
    {
        float interval = duration / blinkCount;

        int count = 0;
        this.ExRepeatCoroutine(interval * 0.5f, () => 
        {
            Lock = (count % 2 == 0);
            count++;
        }, blinkCount * 2);
    }
    
    public void Fadeout(float duration)
    {
        float alpha = 1;
        DOTween.To(() => alpha, (_a) => { alpha = _a; SetAlpha(_a); }, 0, duration).From(1);
    }
    
    public void Fadein(float duration)
    {
        float alpha = 0;
        DOTween.To(() => alpha, (_a) => { alpha = _a; SetAlpha(_a); }, 1, duration).From(0);
    }

    public void Glowout(float duration)
    {
        float glow = 20;
        DOTween.To(() => glow, (_g) => { glow = _g; SetGlow(_g); }, 0, duration).From(20).SetEase(Ease.OutQuad);
    }
    public void Glowin(float duration)
    {
        float glow = 0;
        DOTween.To(() => glow, (_g) => { glow = _g; SetGlow(_g); }, 100, duration).From(0).SetEase(Ease.InQuad);
    }
    

    // 특정색으로 깜빡거리는 효과
    public void StartKeepFlickingToColor(Color color)
    {
        StartCoroutine(CoKeepFlickerColor(color));
    }
    IEnumerator CoKeepFlickerColor(Color targetColor)
    {
        float interval = 0.2f;
        while(true)
        {
            SetColor(targetColor);
            yield return new WaitForSeconds(interval);
            SetColor(Color.white);
            yield return new WaitForSeconds(interval);
            
            if(interval > 0.05f)
                interval *= 0.8f;
        }
    }

    // 특정색으로 깜빡거리는 효과
    public void StartFlickingToColor(Color color, float interval = 0.1f, int count = 2)
    {
        StartCoroutine(CoFlickerColor(color, interval, count));
    }
    IEnumerator CoFlickerColor(Color targetColor, float interval, int count)
    {
        for(int i = 0; i < count; ++i)
        {
            SetColor(targetColor);
            yield return new WaitForSeconds(interval);
            SetColor(Color.white);
            yield return new WaitForSeconds(interval);
        }
    }
    
    public void SetSkin(string skinName)
    {
        if(mSkeletonMecanim != null)
            mSkeletonMecanim.Skeleton.SetSkin(skinName);
    }
    public void RotateWeapon(float degree)
    {
        if(_WeaponBone == null)
            return;

        _WeaponBone.RotateBone(degree);
    }
    public Vector3 GetWeaponPosition()
    {
        if(_WeaponBone == null)
            return Vector3.zero;

        return _WeaponBone.GetPosition();
    }
}
