using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using Spine.Unity;
using UnityEngine;

public class RendererParticle : RendererBase
{
    private ParticleSystem mPS = null;

    protected override void Awake()
    {
        base.Awake();

        mPS = GetComponent<ParticleSystem>();
    }

    public override void SetRenderState(bool isShow)
    {
        mPS.gameObject.SetActive(isShow);
    }
}
