using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using Spine.Unity;
using UnityEngine;

public class RendererSprite : RendererBase
{
    private SpriteRenderer mRenderer = null;

    protected override void Awake()
    {
        base.Awake();

        mRenderer = GetComponent<SpriteRenderer>();
    }

    public override void SetRenderState(bool isShow)
    {
        mRenderer.enabled = isShow;
    }

    public override Color GetColor()
    {
        return mRenderer.color;
    }
    public override void SetColor(Color color)
    {
        mRenderer.color = color;
    }
    public override float GetAlpha()
    {
        Color color = mRenderer.color;
        return color.a;
    }
    public override void SetAlpha(float alpha)
    {
        Color color = mRenderer.color;
        color.a = alpha;
        mRenderer.color = color;
    }
}
