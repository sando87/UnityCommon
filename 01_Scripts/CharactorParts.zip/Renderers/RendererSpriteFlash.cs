using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using Spine.Unity;
using UnityEngine;

public class RendererSpriteFlash : RendererBase
{
    private Renderer mRenderer = null;
    private MaterialPropertyBlock mBlock = null;
    private int mPropertyToIDColor = 0;
    private int mPropertyToIDBrightness = 0;
    private int mPropertyToIDAlpha = 0;

    protected override void Awake()
    {
        base.Awake();

        mPropertyToIDColor = Shader.PropertyToID("_Color");
        mPropertyToIDBrightness = Shader.PropertyToID("_Brightness");
        mPropertyToIDAlpha = Shader.PropertyToID("_Alpha");
        
        mBlock = new MaterialPropertyBlock();
        mRenderer = GetComponent<Renderer>();
        mRenderer.GetPropertyBlock(mBlock);
        mBlock.SetColor(mPropertyToIDColor, Color.white);
        mBlock.SetFloat(mPropertyToIDBrightness, 0);
        mBlock.SetFloat(mPropertyToIDAlpha, 1);
    }

    public override void SetRenderState(bool isShow)
    {
        mRenderer.enabled = isShow;
    }

    public override Color GetColor()
    {
        if(mPropertyToIDColor == 0) return Color.white;

        Color color = mBlock.GetColor(mPropertyToIDColor);
        color.a = 1;
        return color;
    }
    public override void SetColor(Color color)
    {
        if(mPropertyToIDColor == 0) return;

        color.a = 1;
        mBlock.SetColor(mPropertyToIDColor, color);
        mRenderer.SetPropertyBlock(mBlock);
    }
    public override float GetAlpha()
    {
        if(mPropertyToIDAlpha == 0) return 1;

        return mBlock.GetFloat(mPropertyToIDAlpha);
    }
    public override void SetAlpha(float alpha)
    {
        if(mPropertyToIDAlpha == 0) return;

        mBlock.SetFloat(mPropertyToIDAlpha, alpha);
        mRenderer.SetPropertyBlock(mBlock);
    }
    public override float GetBrightness()
    {
        if(mPropertyToIDBrightness == 0) return 1;

        return mBlock.GetFloat(mPropertyToIDBrightness);
    }
    public override void SetBrightness(float brightness)
    {
        if(mPropertyToIDBrightness == 0) return;

        mBlock.SetFloat(mPropertyToIDBrightness, brightness);
        mRenderer.SetPropertyBlock(mBlock);
    }
}
