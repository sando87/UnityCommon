﻿using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;

public class ShakeOnHit : MonoBehaviour
{
    [SerializeField] float _Duration = 0.2f; // 흔들림의 총 지속시간
    [SerializeField] float _Strength = 0.1f; // 좌우로 최대 흔들림의 강도(유니티 월드좌표계 기준 1)
    [SerializeField] int _Vibrato = 90; // 좌우로 흔들리는 정도(0이면 특정방향으로만 왕복하고 끝남..)
    [SerializeField] float _Randomness = 0; // 이값이 0이면 흔들리는 궤도가 직선적이고, 클수록 무작위 방향으로 흔들림
    [SerializeField] bool _Snapping = false; // 흔들리는 위치를 int단위로 절상한다
    [SerializeField] bool _FadeOut = true; // 흔들림을 끝날때 Fadeout 되면서 할지 여부

    private BaseObject mBaseObject = null;
    private Vector3 mLocalOriginPos = Vector3.zero;

    void Start()
    {
        mBaseObject = this.GetBaseObject();
        mLocalOriginPos = transform.localPosition;

        if(mBaseObject.Health != null)
        {
            mBaseObject.Health.EventDamaged += OnDamaged;
        }
    }

    private void OnDamaged(DamageInfo damage, BaseObject attacker)
    {
        if(damage > 0 && !mBaseObject.Health.IsDead)
        {
            transform.DOKill();
            transform.localPosition = mLocalOriginPos;
            transform.DOShakePosition(_Duration, _Strength, _Vibrato, _Randomness, _Snapping, _FadeOut);
        }
    }
}
