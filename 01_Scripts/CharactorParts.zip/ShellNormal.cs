using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;

public class ShellNormal : SkillBase
{
    [SerializeField] float Distance = 10; // 투사체 날악가는 거리
    [SerializeField] float Duration = 1; // 투사체 날악가는 시간
    //[SerializeField] Vector2 StartVelocity = new Vector2(15, 3);
    [SerializeField][PrefabSelector(Consts.VFXPath)] string IntroVFX = ""; // 투사체 생성 이펙트
    [SerializeField][SFXSelector] string FireStartSFX = ""; // 투사체 발사시 사운드

    public Vector3 PreviousPosition { get; set; } = Vector3.zero;

    void Start()
    {
        if(PreviousPosition.Equals(Vector3.zero))
        {
            PreviousPosition = mBaseObject.Body.Center - (mBaseObject.transform.right * 0.1f);
        }
            
    }

    public override void Fire(BaseObject owner)
    {
        base.Fire(owner);
        DoSimpleShot();
    }

    void Update()
    {
        IInteractable hitObj = RaycastInteractable(PreviousPosition, out Vector3 hitPoint);
        if(hitObj != null)
        {
            EndProjectaile();
        }

        Vector3 dir = mBaseObject.Body.Center - PreviousPosition;
        mBaseObject.Renderer.transform.right = dir.normalized;
        PreviousPosition = mBaseObject.Body.Center;
    }

    // 투사체 발사 및 충돌시 처리까지 모두 이 함수에서 처리(발사 및 피격시 이펙트 처리까지..)
    void DoSimpleShot()
    {
        SoundPlayManager.Instance.PlayInGameSFX(FireStartSFX);
        
        // Shoot 시작 효과 생성 후 몇초뒤 삭제
        ObjectPooling.Instance.InstantiateVFX(IntroVFX, mBaseObject.Body.Center, Quaternion.identity).ReturnAfter(3);

        // 전방 방향으로 발사(이동) 후 종료지점에서 투사체 삭제
        // mBaseObject.CharacterPhy.VelocityX = StartVelocity.x * mBaseObject.transform.right.x;
        // mBaseObject.CharacterPhy.VelocityY = StartVelocity.y;
        // mBaseObject.CharacterPhy.EventCrushed += OnCrushed;
        
        // 전방 방향으로 발사(이동) 후 종료지점에서 투사체 삭제
        Vector3 dest = transform.position + (transform.right * Distance);
        StartCoroutine(MoveProjectileWinding(dest, Duration, () => 
        {
            EndProjectaile();
        }));
    }

    void OnCrushed(Vector3 vel, Vector3 normal)
    {
        EndProjectaile();
    }

    private void EndProjectaile()
    {
        mBaseObject.Health.GetDead(mBaseObject, mBaseObject.Body.Center);
    }

    
    // amp * sin(freq) 의 그래프 형태로 위아래로 움직이며 날아감
    IEnumerator MoveProjectileWinding(Vector3 dest, float duration, System.Action eventEnd, float amp = 0.1f, float freq = 0.5f)
    {
        Vector3 startPos = transform.position;
        float hz = 1 / freq;
        float time = 0;
        Vector3 prePos = startPos;
        float offRad = UnityEngine.Random.Range(0, 2) % 2 == 0 ? 0 : Mathf.PI;
        while(time < duration)
        {
            time += Time.deltaTime;
            float rate = time / duration;
            Vector3 curPos = startPos * (1 - rate) + dest * rate;
            float rad = offRad + time * hz * Mathf.PI * 2.0f;
            float offY = Mathf.Sin(rad) * amp;
            curPos.y += offY;
            transform.position = curPos;
            transform.right = (curPos - prePos).normalized;
            prePos = curPos;
            yield return null;
        }
        eventEnd?.Invoke();
    }
}
