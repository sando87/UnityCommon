using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;

public class SkillBase : MonoBehaviour
{
    protected BaseObject mBaseObject = null;

    void Awake() 
    {
        mBaseObject = this.GetBaseObject();
    }

    public virtual void Fire(BaseObject owner) 
    {
        Owner = owner;
        LayerMaskAttackable = owner.GetLayerMaskAttackable();
    }

    // public System.Action EventHit { get; set; } = null;
    // public System.Action EventEnd { get; set; } = null;
    // public Vector3 Direction { get; set; } = Vector3.right;
    public BaseObject Owner { get; private set; } = null;
    public int LayerMaskAttackable { get; private set; } = 0;

    protected IInteractable RaycastInteractable(Vector3 previousPosition, out Vector3 hitPoint)
    {
        Vector3 dir = transform.position - previousPosition;
        RaycastHit[] hits = Physics.RaycastAll(previousPosition, dir, dir.magnitude, LayerMaskAttackable);
        foreach(RaycastHit hit in hits)
        {
            IInteractable it = hit.collider.GetComponent<IInteractable>();
            if(it != null && it.IsInteractable(InteractType.Hit))
            {
                hitPoint = hit.point + (hit.normal * 0.05f);
                return it;
            }
        }
        
        Collider[] cols = Physics.OverlapSphere(transform.position, 0.1f, LayerMaskAttackable);
        foreach(Collider col in cols)
        {
            IInteractable it = col.GetComponent<IInteractable>();
            if(it != null && it.IsInteractable(InteractType.Hit))
            {
                hitPoint = transform.position;
                return it;
            }
        }

        hitPoint = Vector3.zero;
        return null;
    }

}
