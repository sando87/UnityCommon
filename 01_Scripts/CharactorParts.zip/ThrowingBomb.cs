using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;

public class ThrowingBomb : SkillBase
{
    [SerializeField] public float _DelayUpToExplosion = 0.5f;
    [SerializeField] public float _StartVelX = 10.0f;
    [SerializeField] public float _StartVelY = 16.0f;
    [SerializeField] float _WarningRange = 3.0f;
    [SerializeField] [SFXSelector] string _ThrowingSFX = null;

    public override void Fire(BaseObject owner)
    {
        base.Fire(owner);

        SoundPlayManager.Instance.PlayInGameSFX(_ThrowingSFX);

        mBaseObject = this.GetBaseObject();

        mBaseObject.gameObject.layer = owner.gameObject.layer;
        
        float dir = owner.transform.right.x > 0 ? 1 : -1;
        mBaseObject.CharacterPhy.VelocityX = _StartVelX * dir;
        mBaseObject.CharacterPhy.VelocityY = _StartVelY;

        StartCoroutine(CoRotate());

        StartCoroutine(CoStartToBomb(owner));
    }

    IEnumerator CoStartToBomb(BaseObject owner)
    {
        yield return new WaitForSeconds(1);
        yield return new WaitUntil(() => mBaseObject.CharacterPhy.Velocity.magnitude < 3);
        AlarmAround();
        mBaseObject.Renderer.StartFlickingToColor(Color.red);
        this.ExDelayedCoroutine(_DelayUpToExplosion, () => 
        {
            mBaseObject.Health.GetDead(owner, mBaseObject.Body.Center);
        });
    }

    void AlarmAround()
    {
        // 폭탄이 터지기전 주변에 알림 상호작용을 보낸다(벽으로 막혀있는 지역을 보내지 않는다)
        Collider[] cols = InGameUtils.RaycastSphereInsideWall(mBaseObject.Body.Center, _WarningRange, mBaseObject.GetLayerMaskOpposite());
        foreach(Collider col in cols)
        {
            col.GetInteracted(new InteractParam(InteractType.Alarm, mBaseObject));
        }
    }
    
    void PanicAround()
    {
        // 폭탄이 터지기전 주변에 패닉 상호작용을 보낸다(벽으로 막혀있는 지역을 보내지 않는다)
        Collider[] cols = InGameUtils.RaycastSphereInsideWall(mBaseObject.Body.Center, _WarningRange, mBaseObject.GetLayerMaskOpposite());
        foreach(Collider col in cols)
        {
            col.GetInteracted(new InteractParam(InteractType.Panic, mBaseObject));
        }
    }

    IEnumerator CoRotate()
    {
        Transform target = mBaseObject.Renderer.transform;
        CharacterPhysics phy = mBaseObject.CharacterPhy;
        while(true)
        {
            float rotateSpeed = -phy.VelocityX * 0.3f;
            target.Rotate(new Vector3(0, 0, rotateSpeed));
            yield return null;
        }
    }
    
}
