﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TwinkleOnHit : MonoBehaviour
{
    private BaseObject mBaseObject = null;

    void Start()
    {
        mBaseObject = this.GetBaseObject();
        if(mBaseObject.Health != null)
        {
            mBaseObject.Health.EventDamaged += OnDamaged;
        }
    }

    private void OnDamaged(DamageInfo damage, BaseObject attacker)
    {
        if(damage > 0 && !mBaseObject.Health.IsDead)
        {
            mBaseObject.Renderer.StartTwinkle();
        }
    }
}
