using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;

public class UnitBase : MonoBehaviour
{
    protected BaseObject mBaseObject = null;

    protected virtual void Awake()
    {
        mBaseObject = this.GetBaseObject();
    }
}
