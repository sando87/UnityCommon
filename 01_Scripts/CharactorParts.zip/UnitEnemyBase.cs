using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;

public class UnitEnemyBase : UnitBase, IMapEditorObject, IInitiator
{
    [MySerializable] protected bool IsRightLook = false; // 처음 시작시 적이 배치되는 방향(맵 에디터에서 설정 가능)
    [SerializeField] bool _IsBoss = false;

    public bool IsBoss { get { return _IsBoss; } }

    protected virtual void Start()
    {
        mBaseObject.transform.localRotation = IsRightLook ? Quaternion.identity : Quaternion.Euler(0, 180, 0);
        mBaseObject.Health.EventDamaged += OnDamaged;
        
        if(IsBoss)
            StartCoroutine(CoUpdateBossUIInfo());
    }
    private void OnDamaged(DamageInfo damage, BaseObject attacker)
    {
        if(mBaseObject.Health.IsDead)
        {
            InGameManager.Instance.TotalKillCount++;
        }
    }

    void IMapEditorObject.OnMapEditorValueChanged()
    {
        transform.localRotation = IsRightLook ? Quaternion.identity : Quaternion.Euler(0, 180, 0);
    }
    void IInitiator.OnInitialize()
    {
        transform.localRotation = IsRightLook ? Quaternion.identity : Quaternion.Euler(0, 180, 0);
    }

    IEnumerator CoUpdateBossUIInfo()
    {
        yield return new WaitUntil(() => !mBaseObject.FsmManager.IsCurrentFSM<FsmIdle>());
        
        InGameStarter gameStarter = InGameStarter.FindInstance();
        gameStarter.BossUIInfo.isActivated = true;
        
        while(!mBaseObject.Health.IsDead)
        {
            gameStarter.BossUIInfo.healthRate = mBaseObject.Health.CurrentHealthRate;
            yield return null;
        }

        gameStarter.BossUIInfo.isActivated = false;
    }

}
