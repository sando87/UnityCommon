using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;

public class UnitPlayerBase : UnitBase, IMapEditorObject
{
    [SerializeField] Suit _SuitType = Suit.None;
    [SerializeField] int _NormalSkillCount = 100; // 음수면 무한대
    [SerializeField] int _SpecialSkillCount = 3;
    [SerializeField] [SFXSelector] string _SuitEarnSFX = "";
    [SerializeField] float _DecreaseHealthByMove = 0.2f; // 이동에 따른 체력 감소 비중

    public Suit CurrentSuit { get { return _SuitType; } }
    public int RemainNormalSkillCount { get; set; } = 0;
    public int RemainSpecialSkillCount { get; set; } = 0;
    public PlayerStateInfo PreviousPlayerInfo { get; set; } = null;

    private PlayerFace mPlayerFace = null;
    protected float mAccStamina = 0;
    private Coroutine mCoTryDrop = null;
    
    protected override void Awake()
    {
        base.Awake();
        mPlayerFace = mBaseObject.GetComponentInChildren<PlayerFace>();

        RefillNormalSkill();
        RefillSpecialSkill();
    }

    protected virtual void Start()
    {
        SoundPlayManager.Instance.PlayInGameSFX(_SuitEarnSFX);
        mBaseObject.InteractReceiver.EventInteracted += OnGetItem;
    }

    void Update()
    {
        ConsumeStamina();

        TryDropUnderThinGround();
    }

    private void RefillNormalSkill()
    {
        RemainNormalSkillCount = _NormalSkillCount;
    }
    private void RefillSpecialSkill()
    {
        RemainSpecialSkillCount = _SpecialSkillCount;
    }
    private void RefillSuitHP()
    {
        mBaseObject.Health.RefillHealth();
    }
    public bool IsOutOfSpecialSkillCount()
    {
        return RemainSpecialSkillCount <= 0;
    }

    public PlayerStateInfo GetPlayerStateInfo()
    {
        PlayerStateInfo info = new PlayerStateInfo();
        info.ResourceID = mBaseObject.ResourceID;
        info.SuitType = CurrentSuit;
        info.RemainNormalSkillCount = RemainNormalSkillCount;
        info.RemainSpecialSkillCount = RemainSpecialSkillCount;
        info.MaxSuitHealth = mBaseObject.Health.MaxHealth;
        info.RemainSuitHealth = mBaseObject.Health.CurrentHealth;
        info.UIFaceStates = mPlayerFace == null ? CharacterFaceStates.Idle : mPlayerFace.CurrentFace;
        info.PrevCharactorInfo = PreviousPlayerInfo;
        return info;
    }
    public void SetPlayerStateInfo(PlayerStateInfo info)
    {
        RemainNormalSkillCount = info.RemainNormalSkillCount;
        RemainSpecialSkillCount = info.RemainSpecialSkillCount;
        mBaseObject.Health.LoadHealthInfo(info.RemainSuitHealth);
        PreviousPlayerInfo = info.PrevCharactorInfo;
    }
    private void EquipNewSuit(Suit newSuitType)
    {
        BaseObject newSuitObject = InGameStarter.FindInstance().NewSuitPlayer(newSuitType, mBaseObject.transform.position);
        newSuitObject.transform.right = mBaseObject.transform.right;
        
        if(newSuitType.GetSuitLevel() > _SuitType.GetSuitLevel())
            newSuitObject.PlayerBase.PreviousPlayerInfo = GetPlayerStateInfo();
        else
            newSuitObject.PlayerBase.PreviousPlayerInfo = PreviousPlayerInfo;

        newSuitObject.MotionManager.SetStartMotion<MotionSuitOn>();
        mBaseObject.MotionManager.SwitchMotion<MotionSuitOff>();
    }
    // duration 동안 무적상태
    public void SetImmortal(float duration)
    {
        mBaseObject.Renderer.StartBlink(duration, 5);
        mBaseObject.Health.LockDamageable(true);
        this.ExDelayedCoroutine(duration, () => mBaseObject.Health.LockDamageable(false));
    }
    // 캐릭이 낭떠러지로 떨어진 경우 이전 기본 캐릭까지 같이 한꺼번에 죽어야 할 경우..
    public void ResetPreviousPlayerInfo()
    {
        PreviousPlayerInfo = null;
    }

    void IMapEditorObject.OnInitMapEditor()
    {
        enabled = false;
    }
    private void ConsumeStamina()
    {
        if(CurrentSuit == Suit.None)
            return;

        mAccStamina += _DecreaseHealthByMove * (Mathf.Abs(mBaseObject.CharacterPhy.VelocityX) * Time.deltaTime);
        if(mAccStamina >= 1)
        {
            int subHP = (int)mAccStamina;
            mAccStamina -= subHP;
            mBaseObject.Health.ConsumeStamina(subHP);
        }
    }
    
    //  얇은 지형위에서 아래 방향키를 누르면 아래로 떨어지는 로직
    void TryDropUnderThinGround()
    {
        if(mCoTryDrop == null && mBaseObject.CharacterInput.VerticalMove < -Consts.VerticalMoveThreshold)
        {
            if (mBaseObject.CharacterPhy.Velocity.y == 0
            && mBaseObject.Body.IsGrounded
            && IsOnTheThinGround())
            {
                mCoTryDrop = StartCoroutine(CoSideStepOnTryingDown());
            }
        }
    }

    IEnumerator CoSideStepOnTryingDown()
    {
        RaycastHit hit = new RaycastHit();
        while(true)
        {
            if (mBaseObject.Body.RaycastUnderFoot(1.05f, 1 << LayerID.Platforms, out hit))
            {
                float dir = mBaseObject.transform.right.x;
                mBaseObject.CharacterPhy.VelocityX = -3 * dir;
            }
            else if(mBaseObject.Body.RaycastUnderFoot(-1.05f, 1 << LayerID.Platforms, out hit))
            {
                float dir = mBaseObject.transform.right.x;
                mBaseObject.CharacterPhy.VelocityX = 3 * dir;
            }
            else
            {
                mBaseObject.CharacterPhy.VelocityX = 0;
                mBaseObject.transform.position -= new Vector3(0, Consts.DropDistance, 0);
                yield return new WaitUntil(() => mBaseObject.CharacterInput.VerticalMove > -Consts.VerticalMoveThreshold);
                break;
            }

            yield return null;
            if(mBaseObject.CharacterInput.VerticalMove > -Consts.VerticalMoveThreshold)
                break;
        }
        
        mBaseObject.CharacterPhy.VelocityX = 0;
        mCoTryDrop = null;
    }
    
    private bool IsOnTheThinGround()
    {
        RaycastHit hit = new RaycastHit();
        if(mBaseObject.Body.RaycastUnderFoot(-0.95f, 1 << LayerID.PlatformsThin, out hit)
            || mBaseObject.Body.RaycastUnderFoot(0.95f, 1 << LayerID.PlatformsThin, out hit))
        {
            BoxCollider boxCol = hit.collider as BoxCollider;
            return boxCol.size.y < Consts.DropDistance;
        }
        return false;
    }
    
    public IEnumerator DrawBombThrowCurve(BaseObject throwingPrefab, float startVelX, float startVelY)
    {
        yield return null;

        CharacterPhysics phy = throwingPrefab.GetComponent<CharacterPhysics>();
        BodyCollider body = throwingPrefab.GetComponentInChildren<BodyCollider>();
        if(phy == null || body == null)
            yield break;

        float velX = startVelX;
        float velY = startVelY * 1.044f;
        Vector3[] points = phy.SimulateLocalPoints(new Vector3(velX, velY, 0), 3, 0.05f);
        PointRenderer pr = PointRenderer.DrawLocal(points, new Color(1.0f, 1.0f, 1.0f, 0.5f), 4, mBaseObject.Body.transform);
        
        while(true)
        {
            pr.gameObject.SetActive(false);
            yield return new WaitUntil(() => mBaseObject.CharacterInput.AttackSpecial && RemainSpecialSkillCount > 0);
            pr.gameObject.SetActive(true);
            pr.Flow();

            float time = 0;
            while(mBaseObject.CharacterInput.AttackSpecial)
            {
                Vector3[] worldPoints = pr.GetWorldPoints();
                int hitIndex = CalculateIndexUpToHit(body.Size, worldPoints, mBaseObject.Body.Center);
                pr.ShowPoints(0, hitIndex);

                yield return null;

                if(time > (0.48f + hitIndex * 0.05f))
                {
                    time = 0;
                    pr.Flow();
                }
                else
                {
                    time += Time.deltaTime;
                }
            }
        }
        
    }
    private int CalculateIndexUpToHit(Vector3 bombSize, Vector3[] points, Vector3 startPoint)
    {
        Vector3 prvPoint = startPoint;
        for(int i = 0; i < points.Length; ++i)
        {
            Vector3 ds = points[i] - prvPoint;
            if(Physics.BoxCast(prvPoint, bombSize * 0.5f, ds.normalized, out RaycastHit hit, Quaternion.identity, ds.magnitude, 1 << LayerID.Platforms))
            {
                return i;
            }

            prvPoint = points[i];
        }
        return points.Length - 1;
    }
    private void OnGetItem(InteractParam param)
    {
        if(!param.type.HasFlag(InteractType.GetItem))
            return;

        ItemBoxCore itemBox = param.interactor.GetComponentInChildren<ItemBoxCore>();
        if(itemBox != null)
        {
            if(itemBox.Type == ItemBoxCore.ItemType.AMMO)
                RefillNormalSkill();
            else if(itemBox.Type == ItemBoxCore.ItemType.Special)
                RefillSpecialSkill();
            else if(itemBox.Type == ItemBoxCore.ItemType.SuitRepair)
                RefillSuitHP();

            mPlayerFace.SetFaceTrigger(CharacterFaceStates.GetItems);
        }
        
        SuitItem suitBox = param.interactor.GetComponentInChildren<SuitItem>();
        if(suitBox != null)
        {
            EquipNewSuit(suitBox.SuitType);
        }
    }
}
